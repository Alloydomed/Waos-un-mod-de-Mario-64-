-- name: MarioTale (Undertale OST in SM64)
-- description: Songs from the Undertale matched into places of SM64 Music. By PixelatedCheese1


-- Water Levels need Custom Configuration
local function waterlevels()
    local level = gNetworkPlayers[0].currLevelNum
    local seq = get_current_background_music() 

    if seq == SEQ_STAFF_ROLL then
        return
    end

    if level == LEVEL_JRB or level == LEVEL_DDD then
        set_background_music(0, 0x23, 60)
    end
end

hook_event(HOOK_ON_LEVEL_INIT, waterlevels)
hook_event(HOOK_ON_WARP, waterlevels)


--Music
smlua_audio_utils_replace_sequence(0x04, 0x0E, 64, "ruins") -- Castle
smlua_audio_utils_replace_sequence(0x03, 0x0E, 64, "enemyapproaching") -- BOB/Grass Levels
smlua_audio_utils_replace_sequence(0x16, 0x0E, 64, "bonetrousle") -- Boss Fights
smlua_audio_utils_replace_sequence(0x08, 0x0E, 64, "snowdintown") -- Snowy Areas
smlua_audio_utils_replace_sequence(0x09, 0x0E, 64, "spiderdance") -- Slider
smlua_audio_utils_replace_sequence(0x0E, 0x0E, 64, "histheme") -- Wing Cap/Vanish Cap
smlua_audio_utils_replace_sequence(0x23, 0x0E, 64, "waterfall") -- Water Levels
smlua_audio_utils_replace_sequence(0x06, 0x25, 128, "core") -- Lava/Sand Levels
smlua_audio_utils_replace_sequence(0x0C, 0x25, 128, "hereweare") -- Underground Levels
smlua_audio_utils_replace_sequence(0x0A, 0x0E, 128, "ghostfight") -- Spooky Levels
smlua_audio_utils_replace_sequence(0x07, 0x25, 64, "asgore") -- Normal Bowser Fights
smlua_audio_utils_replace_sequence(0x11, 0x25, 64, "spearofjustice") -- Bowser Levels
smlua_audio_utils_replace_sequence(0x19, 0x25, 64, "mega") -- FINAL BOWSER

--Jingles
smlua_audio_utils_replace_sequence(0x0D, 0x25, 64, "bergentruckung") -- Star Select




